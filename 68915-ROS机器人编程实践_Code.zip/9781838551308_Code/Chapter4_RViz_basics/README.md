# Creating the virtual two wheeled ROS robot

The files in this folder provide the code samples for "Chapter 4: Creating the virtual two wheeled ROS robot" of the book "Hands-on ROS for Robotics Programming"