# Simulating the robot behavior in a virtual environment with Gazebo

The files in this folder provide the code samples for "Chapter 5: Simulating the robot behavior in a virtual environment with Gazebo" of the book "Hands-on ROS for Robotics Programming"