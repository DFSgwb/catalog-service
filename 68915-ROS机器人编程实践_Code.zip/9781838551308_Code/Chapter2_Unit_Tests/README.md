# Unit testing of GoPiGo3

The files in this folder provide the code samples for "Chapter 2: Unit testing of GoPiGo3" of the book "Hands-on ROS for Robotics Programming"
